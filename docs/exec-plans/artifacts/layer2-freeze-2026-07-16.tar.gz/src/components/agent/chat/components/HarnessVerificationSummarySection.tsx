import type { AgentRuntimeEvidenceVerificationSummary } from "@/lib/api/agentRuntime/evidenceTypes";
import { buildHarnessEvidenceVerificationCardPresentations } from "@/lib/agentRuntime/harnessVerificationPresentation";
import { Badge } from "@/components/ui/badge";
import { ShieldAlert } from "lucide-react";
import { useTranslation } from "react-i18next";

export function HarnessVerificationSummarySection({
  summary,
}: {
  summary: AgentRuntimeEvidenceVerificationSummary;
}) {
  const { i18n, t } = useTranslation("agent");
  const locale = i18n.language;

  return (
    <div className="rounded-xl border border-border bg-background p-3">
      <div className="flex items-center gap-2 text-sm font-medium text-foreground">
        <ShieldAlert className="h-4 w-4 text-emerald-600" />
        <span>{t("agentChat.harnessVerification.section.title")}</span>
      </div>
      <div className="mt-3 grid min-w-0 gap-2 [grid-template-columns:repeat(auto-fit,minmax(min(100%,11rem),1fr))]">
        {buildHarnessEvidenceVerificationCardPresentations(summary, {
          locale,
          t,
        }).map((card) => (
          <div
            key={card.key}
            className="rounded-lg border border-border/70 bg-muted/20 p-3"
          >
            <div className="flex items-center justify-between gap-2">
              <span className="text-sm font-medium text-foreground">
                {card.title}
              </span>
              <Badge variant={card.badge.variant}>{card.badge.label}</Badge>
            </div>
            <div className="mt-2 text-xs text-muted-foreground">
              {card.description}
            </div>
          </div>
        ))}
      </div>

      {summary.focus_verification_failure_outcomes.length > 0 ? (
        <div className="mt-3 rounded-lg border border-amber-200 bg-amber-50/80 p-3">
          <div className="text-sm font-medium text-amber-900">
            {t("agentChat.harnessVerification.section.failureFocusTitle")}
          </div>
          <div className="mt-2 space-y-1 text-xs text-amber-800">
            {summary.focus_verification_failure_outcomes.map(
              (outcome, index) => (
                <div key={`${outcome}-${index}`}>{outcome}</div>
              ),
            )}
          </div>
        </div>
      ) : null}

      {summary.focus_verification_recovered_outcomes.length > 0 ? (
        <div className="mt-3 rounded-lg border border-emerald-200 bg-emerald-50/80 p-3">
          <div className="text-sm font-medium text-emerald-900">
            {t("agentChat.harnessVerification.section.recoveredTitle")}
          </div>
          <div className="mt-2 space-y-1 text-xs text-emerald-800">
            {summary.focus_verification_recovered_outcomes.map(
              (outcome, index) => (
                <div key={`${outcome}-${index}`}>{outcome}</div>
              ),
            )}
          </div>
        </div>
      ) : null}
    </div>
  );
}
